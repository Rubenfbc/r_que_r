module.exports = {
	repo: 'ampproject/amp-wp',
	path: 'assets/js/**/*',
	branch: 'develop',
	findRenamed: '[name]-[extname]',
};
