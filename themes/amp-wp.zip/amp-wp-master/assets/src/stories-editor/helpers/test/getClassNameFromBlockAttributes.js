describe( 'getClassNameFromBlockAttributes', () => {
	it.todo( 'add tests' );
} );
