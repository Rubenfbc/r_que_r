describe( 'createSkeletonTemplate', () => {
	it.todo( 'add tests' );
} );
