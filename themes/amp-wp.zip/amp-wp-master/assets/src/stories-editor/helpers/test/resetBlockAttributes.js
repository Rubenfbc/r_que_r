describe( 'resetBlockAttributes', () => {
	it.todo( 'add tests' );
} );
