/**
 * WordPress dependencies
 */
import * as serverSideRender from '@wordpress/server-side-render';

window.wp = window.wp || {};

window.wp.serverSideRender = serverSideRender;
