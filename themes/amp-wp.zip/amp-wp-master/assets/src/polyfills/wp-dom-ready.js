/**
 * WordPress dependencies
 */
import domReady from '@wordpress/dom-ready';

window.wp = window.wp || {};

window.wp.domReady = domReady;
