/**
 * WordPress dependencies
 */
import * as i18n from '@wordpress/i18n';

window.wp = window.wp || {};

window.wp.i18n = i18n;
