<?php
/**
 * Plugin Name: E2E Tests Demo Plugin
 * Plugin URI:  https://github.com/ampproject/amp-wp
 * Description: Demo Plugin that can be installed during E2E tests.
 * Author:      AMP Project Contributors
 * Author URI:  https://github.com/ampproject/amp-wp/graphs/contributors
 */

// Silence is golden.
